#
# Individual.py
#
#
from autochess_sys import *
import math

class Individual:
    """
    Individual
    """  
    def __init__(self):
        self.strength= 0
        chesstypelist = system.chesstypelist
        level = len(chesstypelist)
        types = max(chesstypelist) 
        self.hand_cards = np.zeros((3,level,types))
        self.money = 0
        self.level = 1
        

        self.fit=None
    def hand_cards(self,chess):
        self.hand_cards[0][chess[0]][chess[1]]+=1
    def refreshtable(self):
        self.money = self.money - 2
        return system.chessoffer(self.level)
                
    def state_check(self):# state_check should be a binary tree
        self.hand_cards[1] = self.hand_cards[0]/3
        self.hand_cards[1] = self.hand_cards[1].astype(int)
        self.hand_cards[1] = self.hand_cards[1].astype(float)
        self.hand_cards[2] = self.hand_cards[1]/3
        self.hand_cards[2] = self.hand_cards[2].astype(int)
        self.hand_cards[2] = self.hand_cards[2].astype(float)
    def choicetime(self, epoch):
        # in a single epoch, a player should go through three part : get money, buying, end epoch
        # buying is the most tricky part of this game, it needs a 'brain'
        money += system.money_offer(self.money, epoch)
        chess_table = system.chessoffer(self.level)
        
